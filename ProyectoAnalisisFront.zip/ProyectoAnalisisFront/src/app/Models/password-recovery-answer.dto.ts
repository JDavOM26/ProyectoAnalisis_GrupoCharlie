
export interface PasswordRecoveryAnswerDto {
  respuesta: string;
  idUsuario: string;
}
