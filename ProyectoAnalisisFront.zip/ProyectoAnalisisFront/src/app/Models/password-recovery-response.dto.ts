
export interface PasswordRecoveryResponseDto {
  pregunta: string;
}
